﻿using Newtonsoft.Json;
using Orient.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Infrastructure.Models;

namespace WindowsFormsApp1
{
 
    public partial class FormDetails : Form
    {
        private Category localCat;

        public FormDetails()
        {
            InitializeComponent();
        }

        public FormDetails(Category c)
        {
            InitializeComponent();
            localCat = c;
            this.Text = "Category of Beer: " + c.Name;
        }

        private void FormDetails_Load(object sender, EventArgs e)
        {

            if (localCat != null)
            {
                ODatabase odb = new ODatabase("127.0.0.1", 2424, "openbeerdb", ODatabaseType.Graph, "admin", "admin", "");
                var data = odb.Command(string.Format("SELECT EXPAND( BOTH() ) FROM Category WHERE id={0}", localCat.Id));
                List<Style> styles = new List<Style>();
                foreach (var entry in data.ToList())
                {

                    string ss = JsonConvert.SerializeObject(entry);
                    var b = JsonConvert.DeserializeObject<Style>(ss);
                    if (b.Name != null && b.ClassName.Equals("Style", StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (b.Name != null)
                        {
                            var chk = styles.Where(st => st.Name.Equals(b.Name)).FirstOrDefault();
                            if (chk == null)
                            {
                                styles.Add(b);
                            }
                        }
                    }
                }
                odb.Close();
                listBox1.DataSource = styles.OrderBy(b => b.Name).ToList(); ;
                listBox1.DisplayMember = "Name";

            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            ODatabase odb = new ODatabase("127.0.0.1", 2424, "openbeerdb", ODatabaseType.Graph, "admin", "admin", "");
            var data = odb.Command(string.Format("SELECT  EXPAND( BOTH() )  FROM Style where id={0} ", ((Style)listBox1.SelectedItem).Id));
            List<Beer> beers = new List<Beer>();
            foreach (var entry in data.ToList())
            {

                string ss = JsonConvert.SerializeObject(entry);
                var b = JsonConvert.DeserializeObject<Beer>(ss);
                if (b.Name != null && b.ClassName.Equals("Beer", StringComparison.InvariantCultureIgnoreCase))
                {
                    var chk = beers.Where(st => st.Name.Equals(b.Name)).FirstOrDefault();
                    if (chk == null)
                    {
                        beers.Add(b);
                    }
                }
            }
            odb.Close();
            listBox2.DataSource = beers.OrderBy(b => b.Name).ToList(); ;
            listBox2.DisplayMember = "Name";

            listBox3.DataSource = new List<Brewery>();
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            ODatabase odb = new ODatabase("127.0.0.1", 2424, "openbeerdb", ODatabaseType.Graph, "admin", "admin", "");
            var data = odb.Command(string.Format("SELECT  EXPAND( BOTH() )  FROM Beer where id={0} ", ((Beer)listBox2.SelectedItem).Id));
            List<Brewery> breweries = new List<Brewery>();
            foreach (var entry in data.ToList())
            {

                string ss = JsonConvert.SerializeObject(entry);
                var b = JsonConvert.DeserializeObject<Brewery>(ss);
                if (b.Name != null && b.ClassName.Equals("Brewery", StringComparison.InvariantCultureIgnoreCase))
                {
                    var chk = breweries.Where(st => st.Name.Equals(b.Name)).FirstOrDefault();
                    if (chk == null)
                    {
                        breweries.Add(b);
                    }
                }
            }
            odb.Close();
            listBox3.DataSource = breweries.OrderBy(b => b.Name).ToList(); ;
            listBox3.DisplayMember = "Name";


        }
    }
}
