﻿using Newtonsoft.Json;
using Orient.Client;
using Orient.Client.API.Query;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Infrastructure.Models;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            List<Category> cats = new List<Category>();

            ODatabase odb = new ODatabase("127.0.0.1", 2424, "openbeerdb", ODatabaseType.Graph, "admin", "admin", "");
            var data = odb.Command("SELECT * FROM Category");

            // LOOP OVER DATA
            foreach (var entry in data.ToList())
            {
                string ss = JsonConvert.SerializeObject(entry);
                var c = JsonConvert.DeserializeObject<Category>(ss);
                cats.Add(c);
                
            }

            odb.Close();

            comboBox1.DataSource=  cats;
            comboBox1.DisplayMember = "Name";


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var rec = (Category)comboBox1.SelectedItem;
            FormDetails frm = new FormDetails(rec);

            frm.Show();

        }
    


    }
}
