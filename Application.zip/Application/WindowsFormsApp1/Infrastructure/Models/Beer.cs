﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.Infrastructure.Models
{
    class Beer
    {
        public int Id { get; set; }

        [JsonProperty("@OClassName")]
        public string ClassName { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("cat_id")]
        public int CategoryId { get; set; }

        [JsonProperty("style_id")]
        public int Styleid { get; set; }

        [JsonProperty("brewery_id")]
        public int breweryid { get; set; }

        [JsonProperty("style_name")]
        public string StyleName { get; set; }


    }
}
